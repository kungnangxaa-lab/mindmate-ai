const CATEGORIES = [
  { key: "study", emoji: "📚", label: "ปัญหาการเรียน" },
  { key: "friends", emoji: "👭", label: "ปัญหาเพื่อน" },
  { key: "family", emoji: "🏠", label: "ปัญหาครอบครัว" },
  { key: "stress", emoji: "😰", label: "ความเครียดและความกังวล" },
  { key: "relationship", emoji: "💕", label: "ความสัมพันธ์" },
  { key: "school", emoji: "🏫", label: "ปัญหาในโรงเรียน" },
  { key: "time", emoji: "⏰", label: "การจัดการเวลา" },
  { key: "money", emoji: "💰", label: "การเงินสำหรับนักเรียน" },
];

const ADVICE_BANK = {
  study: [
    "ลองแบ่งเนื้อหาที่ต้องอ่านเป็นส่วนเล็ก ๆ แล้วตั้งเวลาอ่านทีละ 25 นาที พัก 5 นาที (เทคนิค Pomodoro) จะช่วยให้ไม่ท้อและจำได้ดีขึ้นนะ",
    "ถ้าเรียนไม่ทัน ลองปรึกษาเพื่อนหรือครูที่ปรึกษาดูก่อน อย่าเก็บไว้คนเดียว การถามคือก้าวแรกของการเข้าใจ",
    "ลองทำสรุปด้วยคำพูดของตัวเองหลังเรียนจบแต่ละคาบ จะช่วยให้จำได้แม่นกว่าการอ่านซ้ำเฉย ๆ",
  ],
  friends: [
    "ความสัมพันธ์กับเพื่อนบางครั้งก็มีขึ้นมีลง ลองพูดคุยตรง ๆ ด้วยน้ำเสียงสงบ บอกความรู้สึกของเราแบบไม่โทษอีกฝ่าย",
    "ถ้ารู้สึกโดนเพื่อนไม่เข้าใจ ลองให้เวลาตัวเองสักหน่อย แล้วค่อยกลับไปคุยเมื่อใจเราสงบขึ้น",
    "เพื่อนแท้ไม่จำเป็นต้องเยอะ การมีเพื่อนที่เข้าใจเราจริง ๆ สักคนสองคนก็มีค่ามากแล้ว",
  ],
  family: [
    "ปัญหาครอบครัวเป็นเรื่องละเอียดอ่อน ลองหาจังหวะที่ทุกคนใจเย็นแล้วค่อยคุยกัน จะช่วยให้เข้าใจกันมากขึ้น",
    "ถ้าคุยตรง ๆ ยาก ลองเขียนความรู้สึกเป็นจดหมายสั้น ๆ ให้คนในครอบครัวอ่านก็เป็นอีกทางเลือกหนึ่ง",
    "อย่าลืมว่าเราไม่ได้อยู่คนเดียว ถ้าหนักใจมากลองปรึกษาคุณครูแนะแนวหรือญาติที่ไว้ใจได้",
  ],
  stress: [
    "เวลาเครียดลองหายใจเข้าลึก ๆ นับ 1-4 แล้วค่อย ๆ ผ่อนลมหายใจออกนับ 1-4 ทำซ้ำสัก 5 รอบ จะช่วยให้ใจสงบขึ้น",
    "ลองแบ่งเวลาทำสิ่งที่ชอบวันละนิด เช่น ฟังเพลง วาดรูป หรือเดินเล่น จะช่วยผ่อนคลายความเครียดได้",
    "ถ้าความกังวลเริ่มรบกวนการใช้ชีวิตประจำวันมาก ๆ การพูดคุยกับผู้ใหญ่ที่ไว้ใจหรือนักจิตวิทยาโรงเรียนจะช่วยได้มาก",
  ],
  relationship: [
    "ความสัมพันธ์ที่ดีเริ่มจากการฟังกันและกันอย่างตั้งใจ ลองเปิดใจคุยถึงสิ่งที่คาดหวังจากกันและกัน",
    "ถ้ารู้สึกไม่แน่ใจในความสัมพันธ์ ลองให้เวลาตัวเองคิดทบทวนก่อนตัดสินใจอะไรที่สำคัญ",
    "การเคารพพื้นที่ส่วนตัวของกันและกันก็สำคัญไม่แพ้ความใกล้ชิด",
  ],
  school: [
    "ถ้ามีปัญหากับกฎระเบียบหรือครูในโรงเรียน ลองปรึกษาครูที่ปรึกษาหรือฝ่ายแนะแนวเพื่อหาทางออกร่วมกัน",
    "การปรับตัวเข้ากับสภาพแวดล้อมใหม่ ๆ ต้องใช้เวลา ค่อย ๆ เป็นค่อย ๆ ไปนะ ไม่ต้องรีบ",
    "ลองมองหากิจกรรมหรือชมรมที่สนใจ จะช่วยให้รู้สึกเป็นส่วนหนึ่งของโรงเรียนมากขึ้น",
  ],
  time: [
    "ลองทำตารางเวลาแบบง่าย ๆ แบ่งงานเป็นเรื่องเร่งด่วนกับไม่เร่งด่วน จะช่วยให้จัดลำดับความสำคัญได้ดีขึ้น",
    "การตั้งเป้าหมายเล็ก ๆ ในแต่ละวันจะช่วยให้ไม่รู้สึกว่างานเยอะจนล้นมือ",
    "อย่าลืมเผื่อเวลาพักผ่อนไว้ในตารางด้วยนะ การพักคือส่วนหนึ่งของการจัดการเวลาที่ดี",
  ],
  money: [
    "ลองจดบันทึกรายรับรายจ่ายง่าย ๆ ทุกวัน จะช่วยให้เห็นภาพรวมการใช้เงินของเราชัดขึ้น",
    "การแบ่งเงินเป็นส่วน ๆ เช่น ค่าใช้จ่ายจำเป็น เงินเก็บ และเงินใช้จ่ายส่วนตัว จะช่วยให้บริหารเงินง่ายขึ้น",
    "ถ้ามีปัญหาเรื่องเงินที่หนักใจ ลองปรึกษาผู้ปกครองหรือครูแนะแนวเพื่อหาทางช่วยเหลือ",
  ],
};

const ENCOURAGEMENT = [
  "ไม่ว่าจะเจออะไรอยู่ตอนนี้ เธอไม่ได้เผชิญมันคนเดียวนะ 💙",
  "ทุกปัญหามีทางออกเสมอ แค่ต้องใช้เวลาสักหน่อย สู้ ๆ นะ",
  "การที่เธอกล้าเล่าปัญหาออกมา ก็ถือเป็นก้าวที่ดีมากแล้ว",
  "เป็นกำลังใจให้เสมอนะ เธอเก่งกว่าที่คิดไว้เยอะเลย",
];

const menuGrid = document.getElementById("menuGrid");
const categorySelect = document.getElementById("categorySelect");
const problemText = document.getElementById("problemText");
const errorMsg = document.getElementById("errorMsg");
const adviceBtn = document.getElementById("adviceBtn");
const adviceCard = document.getElementById("adviceCard");
const adviceOutput = document.getElementById("adviceOutput");

let selectedCategory = CATEGORIES[0].key;

function renderMenu() {
  menuGrid.innerHTML = "";
  CATEGORIES.forEach((cat) => {
    const div = document.createElement("div");
    div.className = "menu-item" + (cat.key === selectedCategory ? " active" : "");
    div.innerHTML = `<span class="emoji">${cat.emoji}</span><span>${cat.label}</span>`;
    div.addEventListener("click", () => {
      selectedCategory = cat.key;
      categorySelect.value = cat.key;
      renderMenu();
    });
    menuGrid.appendChild(div);
  });
}

function renderSelect() {
  categorySelect.innerHTML = "";
  CATEGORIES.forEach((cat) => {
    const opt = document.createElement("option");
    opt.value = cat.key;
    opt.textContent = `${cat.emoji} ${cat.label}`;
    categorySelect.appendChild(opt);
  });
  categorySelect.value = selectedCategory;
}

categorySelect.addEventListener("change", (e) => {
  selectedCategory = e.target.value;
  renderMenu();
});

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

adviceBtn.addEventListener("click", () => {
  const text = problemText.value.trim();
  if (!text) {
    errorMsg.textContent = "กรุณาพิมพ์เล่าปัญหาของคุณก่อนกดขอคำแนะนำนะ";
    adviceCard.hidden = true;
    return;
  }
  errorMsg.textContent = "";

  const tips = ADVICE_BANK[selectedCategory] || [];
  const advice = pickRandom(tips);
  const cheer = pickRandom(ENCOURAGEMENT);

  adviceOutput.textContent = `${advice}\n\n${cheer}`;
  adviceCard.hidden = false;
  adviceCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
});

renderMenu();
renderSelect();
